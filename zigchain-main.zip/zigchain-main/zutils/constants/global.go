package constants

const (
	AddressPrefix  = "zig"
	BlockChainName = "zigchain"
	CoinType       = 118
)
