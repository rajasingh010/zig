package constants

// Keeper constants
const (
	// MaxIBCCallbackGas should roughly be a couple orders of magnitude larger than needed.
	MaxIBCCallbackGas = uint64(10_000_000)
)
